This is NOT a challenge folder!

This holds source files common to the zombie family of challenges.
