#!/bin/sh

node /ctf/app/index.js