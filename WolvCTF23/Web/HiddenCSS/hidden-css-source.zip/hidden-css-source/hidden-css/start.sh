#!/bin/sh

node /ctf/app/private-server.js&
node /ctf/app/public-server.js