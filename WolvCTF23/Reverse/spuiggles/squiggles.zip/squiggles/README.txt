This problem features a logic capture from a Microchip 25LC640A EEPROM chip. 
The logic capture can be viewed with Saleae's Logic Pro software, available at:
https://www.saleae.com/downloads/

The datasheet for the 25LC640A can be found at:
https://ww1.microchip.com/downloads/aemDocuments/documents/MPD/ProductDocuments/DataSheets/25AA640A-25LC640A-64K-SPI-Bus-Serial-EEPROM-20001830G.pdf
