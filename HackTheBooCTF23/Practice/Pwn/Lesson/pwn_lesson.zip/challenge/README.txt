For this challenge, you do not have to pwn the given binary to get the flag.
Answer the questions based on the program and you will be rewarded with the flag.
Connect to the remote instance with: $ nc <IP> <PORT> e.g. nc localhost 1337
