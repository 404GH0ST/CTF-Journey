export const DB_URL = Deno.env.get("DB_URL") || "mongodb://admin:admin@localhost:27017"

