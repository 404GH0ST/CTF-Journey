export const PORT = Number(Deno.env.get("PORT")) || 8080;
export const DOMAIN = Deno.env.get("DOMAIN") || 'localhost';