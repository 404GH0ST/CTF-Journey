import typing as t
from math import ceil


class ADFGVX:
    def __init__(self, keyword: bytes):
        self.headers = b'0123456789ABCDEF'
        self.keyword = keyword
        self.char_to_coords = {}
        self.coords_to_char = {}

        keys = bytes(range(256))
        for i in range(16):
            for j in range(16):
                coords = bytes((self.headers[i], self.headers[j]))
                char = keys[i*16 + j]
                self.char_to_coords[char] = coords
                self.coords_to_char[coords] = char

    def encrypt(self, plaintext: bytes) -> bytes:
        intermediate = b''.join([self.char_to_coords[i] for i in plaintext])
        grid = [
            intermediate[i:i+len(self.keyword)] for i in range(0, len(intermediate), len(self.keyword))
        ]
        order = self.__argsort(self.keyword)
        ciphertext = b''.join(
            j[i:i+1] for i in order for j in grid if i < len(j)
        )
        return ciphertext

    def __argsort(self, seq: bytes) -> t.List[int]:
        return sorted(range(len(seq)), key=seq.__getitem__)
