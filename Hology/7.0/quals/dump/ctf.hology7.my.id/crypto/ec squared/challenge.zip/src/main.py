import base64
import json
import os
import random
import typing as t
from adfgvx import ADFGVX
from enigma import Enigma, Rotor, Reflector


FLAG = open('./flag.txt').read().strip().encode()
assert len(FLAG) == 56


class App:
    def __init__(self):
        self.ROTOR_COUNT = 4
        self.internal_count = 0
        self.signed_message = set()

        self.keyword = os.urandom(8)
        self.adfgvx = ADFGVX(self.keyword)

        self.rotors = [
            Rotor(
                wiring=self.__generate_wiring(),
                notches=[random.randint(0, 255)],
            )
            for _ in range(self.ROTOR_COUNT)
        ]
        self.reflector = Reflector(wiring=self.__generate_involutive_wiring())
        self.plugs = self.__generate_plugs(10)
        self.key = bytes(
            [random.randint(0, 255) for _ in range(self.ROTOR_COUNT)]
        )
        self.ring = bytes(
            [random.randint(0, 255) for _ in range(self.ROTOR_COUNT)]
        )

        self.enigma = Enigma(
            reflector=self.reflector,
            rotors=self.rotors,
            key=self.key,
            plugs=self.plugs,
            ring=self.ring,
        )

        try:
            self.run()
        except KeyboardInterrupt:
            exit()

    def run(self) -> None:
        while True:
            print('1. Sign message')
            print('2. Verify message')
            print('0. Exit')
            match input('Choice: '):
                case '1':
                    message = input('Message: ').encode()
                    try:
                        signature = self.sign(message)
                    except Exception as e:
                        print('Error:', e)
                    else:
                        print('Signature:', signature.decode())
                case '2':
                    message = input('Message: ').encode()
                    signature = input('Signature: ').encode()
                    try:
                        verified = self.verify(message, signature)
                    except Exception as e:
                        print('Error:', e)
                    else:
                        print(
                            'Signature is valid!' if verified else 'Signature is invalid.')
                case '0':
                    return
                case _:
                    print('Invalid choice')
            print()

    def sign(self, message: bytes) -> bytes:
        if message in self.signed_message:
            raise ValueError('Message already signed!')
        self.signed_message.add(message)

        data = {
            'state': self.internal_count,
            'signature': self.__encipher(self.__xor(message, FLAG)).hex(),
        }
        return str(data['state']).encode() + b'.' + self.adfgvx.encrypt(json.dumps(data).encode())

    def verify(self, message: bytes, signature: bytes) -> bool:
        state = signature.split(b'.')[0]
        try:
            state = int(state)
        except ValueError:
            raise ValueError('Invalid state')

        checker = Enigma(
            reflector=self.reflector,
            rotors=self.rotors,
            key=self.key,
            plugs=self.plugs,
            ring=self.ring,
        )

        if state != 0:
            pad = b'\x00' * state
            checker.encipher(pad)

        data = {
            'state': state,
            'signature': checker.encipher(self.__xor(message, FLAG)).hex(),
        }
        target = str(state).encode() + b'.' + \
            self.adfgvx.encrypt(json.dumps(data).encode())
        return signature == target

    def __encipher(self, data: bytes) -> bytes:
        self.internal_count += len(data)
        return self.enigma.encipher(data)

    def __generate_wiring(self) -> bytes:
        lst = list(range(256))
        random.shuffle(lst)
        return bytes(lst)

    def __generate_involutive_wiring(self) -> bytes:
        lst = list(range(256))
        random.shuffle(lst)
        wiring = [0]*256
        while lst:
            a = lst.pop()
            b = lst.pop()
            wiring[a] = b
            wiring[b] = a
        return bytes(wiring)

    def __generate_plugs(self, count: int) -> t.List[t.Tuple[int, int]]:
        plug_pairs = []
        available_bytes = list(range(256))
        random.shuffle(available_bytes)
        for _ in range(count):
            a = available_bytes.pop()
            b = available_bytes.pop()
            plug_pairs.append((a, b))
        return plug_pairs

    def __xor(self, bytes1: bytes, bytes2: bytes) -> bytes:
        if len(bytes1) < len(bytes2):
            bytes1, bytes2 = bytes2, bytes1
        byte = bytearray(bytes1)
        for i, e in enumerate(byte):
            byte[i] = e ^ bytes2[i % len(bytes2)]
        return bytes(byte)


if __name__ == '__main__':
    App()
