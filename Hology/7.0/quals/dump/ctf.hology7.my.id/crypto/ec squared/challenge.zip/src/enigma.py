import typing as t


class Reflector:
    def __init__(self, wiring: t.Optional[bytes] = None) -> None:
        if wiring is not None:
            self.wiring = wiring
        else:
            self.wiring = bytes(range(256))
        self.state = 0

    def encipher(self, key: int) -> int:
        shift = self.state % 256
        index = (key + shift) % 256
        letter = self.wiring[index]
        out = (letter - shift) % 256
        return out


class Rotor:
    def __init__(
        self,
        wiring: t.Optional[bytes] = None,
        notches: t.Optional[t.List[int]] = None,
        state: int = 0,
        ring: int = 0,
    ) -> None:
        if wiring is not None:
            self.wiring = wiring
        else:
            self.wiring = bytes(range(256))
        self.rwiring = bytearray(256)
        for i in range(256):
            self.rwiring[self.wiring[i]] = i
        if notches is not None:
            self.notches = notches
        else:
            self.notches = []
        self.state = state
        self.ring = ring

    def encipher_right(self, key: int) -> int:
        shift = (self.state - self.ring) % 256
        index = (key + shift) % 256
        letter = self.wiring[index]
        out = (letter - shift) % 256
        return out

    def encipher_left(self, key: int) -> int:
        shift = (self.state - self.ring) % 256
        index = (key + shift) % 256
        letter = self.rwiring[index]
        out = (letter - shift) % 256
        return out

    def notch(self, offset: int = 1) -> None:
        self.state = (self.state + offset) % 256

    def is_in_turnover_pos(self) -> bool:
        return self.state in self.notches


class Enigma:
    def __init__(
        self,
        reflector: Reflector,
        rotors: t.List[Rotor],
        key: t.Optional[bytes] = None,
        plugs: t.Optional[t.List[t.Tuple[int, int]]] = None,
        ring: t.Optional[bytes] = None,
    ) -> None:
        if key is None:
            key = b'\x00' * len(rotors)
        if ring is None:
            ring = b'\x00' * len(rotors)
        if plugs is None:
            plugs = []

        if len(key) != len(rotors) or len(ring) != len(rotors):
            raise ValueError('Invalid key or ring configuration.')

        self.reflector = reflector
        self.rotors = rotors

        self.reflector.state = 0
        for i, rotor in enumerate(self.rotors):
            rotor.state = key[i]
            rotor.ring = ring[i]

        plugboard_settings = plugs
        alpha = bytes(range(256))
        alpha_out = bytearray(alpha)
        for k, v in plugboard_settings:
            alpha_out[k] = v
            alpha_out[v] = k

        self.transtab = bytes.maketrans(alpha, alpha_out)

    def encipher(self, plaintext_in: bytes) -> bytes:
        ciphertext = bytearray()
        plaintext = plaintext_in.translate(self.transtab)
        for c in plaintext:
            self.__step_rotors()
            t = c
            for rotor in self.rotors:
                t = rotor.encipher_right(t)
            t = self.reflector.encipher(t)
            for rotor in reversed(self.rotors):
                t = rotor.encipher_left(t)
            ciphertext.append(t)

        res = ciphertext.translate(self.transtab)
        return bytes(res)

    def __step_rotors(self) -> None:
        num_rotors = len(self.rotors)
        step_next = True

        for i in range(num_rotors):
            if step_next:
                self.rotors[i].notch()
                step_next = self.rotors[i].is_in_turnover_pos()
            else:
                break
