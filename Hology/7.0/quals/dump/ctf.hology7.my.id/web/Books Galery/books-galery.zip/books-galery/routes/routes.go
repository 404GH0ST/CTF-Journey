package routes

import (
	"database/sql"

	"books-galery/controllers"

	"github.com/gin-gonic/gin"
)

func MapRouter(router *gin.Engine, db *sql.DB) {
	router.GET("/", controllers.ShowBooks(db))
	router.GET("/book/:book_id", controllers.ShowDetail(db))
}