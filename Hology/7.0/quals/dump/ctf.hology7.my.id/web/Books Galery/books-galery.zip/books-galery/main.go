package main

import (
	"books-galery/database"
	"books-galery/routes"
	"log"

	"github.com/gin-gonic/gin"
)

func main() {
	
	db := database.InitDatabase()

	router := gin.Default()

	router.Static("/images", "./images")

	routes.MapRouter(router, db)

	if err := router.Run(":8080"); err != nil {
		log.Fatalf("Failed to run server: %v", err)
	}
}
