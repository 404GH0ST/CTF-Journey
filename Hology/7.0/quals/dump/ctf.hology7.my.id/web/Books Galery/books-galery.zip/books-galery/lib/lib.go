package lib

import (
	"strings"
)


func SanitizeData(input string) string {
	replacements := []struct {
		old string
		new string
	}{
		{"..", "x"},
		{"--", "x"},
		{"/*", "x"},
		{"HAVING", "x"},
		{"UNION", "x"},
		{"SUBSTRING", "x"},
		{"ASCII", "x"},
		{"SHA1", "x"},
		{"ROW_COUNT", "x"},
		{"SELECT", "x"},
		{"INSERT", "x"},
		{"CASE WHEN", "x"},
		{"INFORMATION_SCHEMA", "x"},
		{"FILE", "x"},
		{"DROP", "x"},
		{"RLIKE", "x"},
		{" IF ", "x"},
		{" OR ", "x"},
		{"CONCAT", "x"},
		{"WHERE", "x"},
		{"UPDATE", "x"},
		{"or 1", "x"},
		{"or 1=1", "x"},
		{"flag", "x"},
		{"txt", "x"},
		{"or true", "x"},
		{"=", ""},
		{"+", "-"},
		{"\\", "x"},
		{"=$", "+$"},
		{"+$", "=$"},
	}

	input = strings.TrimSpace(input)

	for _, r := range replacements {
		input = strings.ReplaceAll(input, r.old, r.new)
	}

	return input
}