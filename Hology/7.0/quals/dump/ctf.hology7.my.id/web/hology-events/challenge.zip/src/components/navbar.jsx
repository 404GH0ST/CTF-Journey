import { getServerSession } from 'next-auth'
import Link from 'next/link'
import NavbarDropdown from './navbar-dropdown'

export default async function Navbar() {
  const session = await getServerSession()

  return (
    <nav className="flex items-center justify-between p-4 lg:px-32 lg:pt-4 font-mono fixed top-0 left-0 right-0">
      <Link href="/">
        <span className="text-fuchsia-600">hology</span>-events
      </Link>
      {session ? <NavbarDropdown name={session.user.name} /> : <Link href="/auth/signin">Login</Link>}
    </nav>
  )
}
