const bcrypt = require('bcrypt')
const { PrismaClient } = require('@prisma/client')

const prisma = new PrismaClient()

async function main() {
  await prisma.event.deleteMany()
  await prisma.team.deleteMany()
  await prisma.user.deleteMany()

  const admin = await prisma.user.upsert({
    where: { username: process.env.ADMIN_USERNAME },
    update: {},
    create: {
      username: process.env.ADMIN_USERNAME,
      password: await bcrypt.hash(process.env.ADMIN_PASSWORD, 5),
      name: process.env.ADMIN_NAME,
      isAdmin: true,
    },
  })

  const becky = await prisma.user.upsert({
    where: { username: 'becky' },
    update: {},
    create: {
      username: 'becky',
      password: await bcrypt.hash(process.env.BECKY_PASSWORD, 5),
      name: 'Becky The Manager',
    },
  })

  const cordaiser = await prisma.user.upsert({
    where: { username: 'cordaiser' },
    update: {},
    create: {
      username: 'cordaiser',
      password: await bcrypt.hash(process.env.CORDAISER_PASSWORD, 5),
      name: 'Cordaiser Wagner',
      events: {
        create: [
          {
            title: 'National Seminar',
            description:
              'Hology 7.0 National Seminar 2024, themed "Building a Foundation of Knowledge in Artificial Intelligence," will be held on November 3, 2024, from 15:00 to 17:00 WIB at the Algoritma Auditorium, Faculty of Computer Science, Brawijaya University. Featuring speakers like Daud Kurnia Tanaamas (Negeri AI founder) and Dr. Esther Setiawan (Google Developer Expert), the event will provide insights into AI development. Hosted by George Abraham and Mevlania Ammara, with Gerda Kalista as moderator.',
            visible: true,
          },
          {
            title: 'National IT Competition',
            description:
              'Hology 7.0 National IT Competition 2024, themed "ICT for Human Capital Development: Leveraging Technology for Indonesian Societal Advancement," features various categories including Competitive Programming, Capture The Flag, Data Mining, UX Design, ICT Business Plan, Software Development, and Game Development. The competition offers a total prize of IDR 26,250,000. Key dates include Gelombang 1 from September 14 to October 7, Gelombang 2 from October 8 to October 20, final submission on October 23, announcement on October 28, tech meeting on October 30, and final awarding on November 3.',
            visible: true,
          },
          {
            title: 'Awarding Night',
            description:
              'Awarding Night will be the grand finale, celebrating the top winners and recognizing outstanding achievements across all competition categories. Participants who have demonstrated exceptional skills and performance will be honored with prestigious awards, making it a memorable conclusion to the event. The ceremony will highlight the hard work and dedication of the competitors, marking the culmination of the competition with recognition and celebration.',
            visible: true,
          },
          {
            title: 'Hology Brand Ambassadors',
            description:
              'Hology 7.0 proudly reveals its brand ambassadors: Nimah, Galvina, Faira, Echa, Aleesha, and Azka. These ambassadors will represent the event, embodying the spirit and mission of Hology 7.0. As faces of the competition, they will help promote the event and engage with the community, bringing energy and enthusiasm to the forefront of the Hology experience.',
            visible: false,
          },
        ],
      },
    },
  })

  const dean = await prisma.user.upsert({
    where: { username: 'dean' },
    update: {},
    create: {
      username: 'dean',
      password: await bcrypt.hash(process.env.DEAN_PASSWORD, 5),
      name: 'Dean The Developer',
    },
  })

  const developer = await prisma.team.create({
    data: {
      name: 'Developer Team',
      members: {
        connect: [{ id: becky.id }, { id: cordaiser.id }],
      },
    },
  })

  const management = await prisma.team.create({
    data: {
      name: 'Management Team',
      members: {
        connect: [{ id: dean.id }, { id: becky.id }],
      },
    },
  })

  const director = await prisma.team.create({
    data: {
      name: 'Board of Directors',
      members: {
        connect: [{ id: admin.id }, { id: dean.id }],
      },
    },
  })

  console.log({ admin, becky, cordaiser, dean, developer, management, director })
}

main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async (e) => {
    console.error(e)
    await prisma.$disconnect()
    process.exit(1)
  })
