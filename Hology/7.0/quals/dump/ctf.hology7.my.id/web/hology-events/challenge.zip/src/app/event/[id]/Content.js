'use client'

import { getEventById } from '@/app/api/actions'
import { Skeleton } from '@/components/ui/skeleton'
import Image from 'next/image'
import { useParams } from 'next/navigation'
import { useEffect, useState } from 'react'

export default function Content() {
  const [event, setEvent] = useState(null)

  const params = useParams()

  useEffect(() => {
    async function fetchEvent() {
      const event = await getEventById(params.id)
      setEvent(event)
    }
    fetchEvent()
  }, [])

  return (
    <div className="px-4 pt-16 lg:px-32 lg:pt-20 grow">
      <div className="relative w-full aspect-[16/3] rounded-lg overflow-hidden">
        <Skeleton className="absolute inset-0" />
        {event && (
          <Image
            src={`https://picsum.photos/seed/${event.id}/1600/300`}
            alt={event.title}
            width={1600}
            height={300}
            className="absolute inset-0"
          />
        )}
      </div>

      <h1 className="text-2xl lg:text-6xl font-bold mt-8 mb-1 lg:mb-2 font-mono">
        {event ? event.title : <Skeleton className="w-full h-16" />}
      </h1>
      <h2 className="text-lg lg:text-3xl mb-12">
        {event ? <p>Published on {new Date(event.createdAt).toDateString()}</p> : <Skeleton className="w-2/3 h-8" />}
      </h2>
      <main className="text-xl grow">
        {event ? (
          event.description
        ) : (
          <>
            <Skeleton className="h-4 mb-1" />
            <Skeleton className="h-4 mb-1" />
            <Skeleton className="w-1/2 h-4" />
          </>
        )}
      </main>
    </div>
  )
}
