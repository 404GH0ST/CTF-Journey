import Link from 'next/link'

export default function Footer() {
  return (
    <footer className="mt-12 text-center mb-4">
      Powered by{' '}
      <Link href="https://hology.ub.ac.id" target="_blank">
        <span className="text-fuchsia-600">hology</span>
      </Link>
    </footer>
  )
}
