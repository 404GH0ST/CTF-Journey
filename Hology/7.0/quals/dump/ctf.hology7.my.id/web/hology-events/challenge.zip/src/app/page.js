import Link from 'next/link'
import { getAllPublicEvents } from './api/actions'
import Navbar from '@/components/navbar'
import Footer from '@/components/footer'
import Image from 'next/image'
import { Skeleton } from '@/components/ui/skeleton'

export default async function Home() {
  const events = await getAllPublicEvents()

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <div className="px-4 pt-16 lg:px-32 lg:pt-20 grow text-center">
        <h1 className="text-2xl lg:text-7xl font-bold lg:mb-2 font-mono">
          Welcome to <span className="text-fuchsia-600">hology</span>-events
        </h1>
        <h2 className="text-lg lg:text-4xl mb-6 lg:mb-12">See our events here.</h2>
        <div className="grid auto-rows-fr lg:grid-cols-3 gap-4">
          {events.map((event) => {
            const readableDate = new Date(event.createdAt).toLocaleDateString('en-US', {
              year: 'numeric',
              month: 'long',
              day: 'numeric',
            })
            return (
              <Link href={`/event/${event.id}`} key={event.id}>
                <div className="h-full hover:bg-white/5 hover:-translate-y-1 transition-all rounded-xl text-center border border-neutral-800 overflow-hidden">
                  <div className="w-full aspect-video relative">
                    <Skeleton className="absolute inset-0 rounded-none" />
                    <Image
                      src={`https://picsum.photos/seed/${event.id}/800/450`}
                      alt={event.title}
                      width={800}
                      height={450}
                      className="absolute inset-0"
                    />
                  </div>
                  <h3 className="text-lg lg:text-3xl font-semibold lg:mb-2 capitalize mt-4">{event.title}</h3>
                  <p className="font-mono mb-4">Published on {readableDate}</p>
                </div>
              </Link>
            )
          })}
        </div>
      </div>
      <Footer />
    </div>
  )
}
