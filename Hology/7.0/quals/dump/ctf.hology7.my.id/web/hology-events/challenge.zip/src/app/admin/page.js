import Footer from '@/components/footer'
import Navbar from '@/components/navbar'
import prisma from '@db'
import { getServerSession } from 'next-auth'

export default async function AdminPanel() {
  const session = await getServerSession()
  const { isAdmin } = (
    await prisma.user.findMany({
      where: {
        name: session.user.name,
      },
      select: {
        isAdmin: true,
      },
    })
  )[0]

  return (
    <div className="h-screen flex flex-col">
      <Navbar />
      <div className="px-4 pt-16 lg:mt-16 lg:px-32 lg:pt-20 text-center grow">
        <h1 className="text-2xl lg:text-7xl font-bold lg:mb-8 font-mono">Admin Panel</h1>
        <h2 className="text-lg lg:text-4xl mb-6 lg:mb-16">
          {isAdmin
            ? 'Congratulations! You have successfully accessed this page.'
            : 'Only admins can access this page. Contact the admin to get access.'}
        </h2>
        {isAdmin && (
          <h3 className="lg:text-2xl">
            Your flag is: <span className="font-mono text-red-500">{process.env.FLAG}</span>
          </h3>
        )}
      </div>
      <Footer />
    </div>
  )
}
