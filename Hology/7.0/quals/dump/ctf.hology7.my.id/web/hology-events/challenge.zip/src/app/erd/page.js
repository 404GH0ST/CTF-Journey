import Footer from '@/components/footer'
import Navbar from '@/components/navbar'
import Image from 'next/image'
import ERD from '@/assets/mermaid-diagram-2024-10-03-110716.png'

export default function Post() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <div className="px-4 pt-16 lg:px-32 lg:pt-20 grow flex flex-col items-center">
        <h2 className="text-lg lg:text-4xl mb-6 lg:mb-12">hology-events_ERD_v1.0</h2>
        <Image src={ERD} width={0} height={400} />
      </div>
      <Footer />
    </div>
  )
}
