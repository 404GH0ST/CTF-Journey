import Footer from '@/components/footer'
import Navbar from '@/components/navbar'
import Content from './Content'

export default function Post() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <Content />
      <Footer />
    </div>
  )
}
