'use server'

import prisma from '@db'
import { PrismaClientValidationError } from '@prisma/client/runtime/library'

export async function getAllEvents(where) {
  try {
    const events = await prisma.event.findMany({
      where: where,
      include: {
        owner: true,
      },
    })
    return events
  } catch (e) {
    if (e instanceof PrismaClientValidationError) {
      throw new Error('PrismaClientValidationError: Argument `where`: Invalid value type provided.')
    }
  }
}

export async function getAllPublicEvents() {
  const events = await getAllEvents({
    visible: true,
  })
  return events
}

export async function getEventById(id) {
  const events = await getAllEvents({
    id: id,
  })
  return events[0]
}
