#!/bin/sh

npx prisma migrate dev
node prisma/seed.js
npm run dev