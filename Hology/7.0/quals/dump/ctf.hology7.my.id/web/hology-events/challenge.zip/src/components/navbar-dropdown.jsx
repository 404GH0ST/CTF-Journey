'use client'

import { signOut } from 'next-auth/react'
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from '@/components/ui/navigation-menu'
import Link from 'next/link'

export default function NavbarDropdown({ name }) {
  return (
    <NavigationMenu>
      <NavigationMenuList>
        <NavigationMenuItem>
          <NavigationMenuTrigger>Hi, {name}!</NavigationMenuTrigger>
          <NavigationMenuContent>
            <Link href="/admin" legacyBehavior passHref>
              <NavigationMenuLink className={navigationMenuTriggerStyle()} role="button">
                Admin Panel
              </NavigationMenuLink>
            </Link>
            <Link href="/erd" legacyBehavior passHref>
              <NavigationMenuLink className={navigationMenuTriggerStyle()} role="button">
                Website ERD
              </NavigationMenuLink>
            </Link>
            <NavigationMenuLink className={navigationMenuTriggerStyle()} role="button" onClick={() => signOut()}>
              Log out
            </NavigationMenuLink>
          </NavigationMenuContent>
        </NavigationMenuItem>
      </NavigationMenuList>
    </NavigationMenu>
  )
}
