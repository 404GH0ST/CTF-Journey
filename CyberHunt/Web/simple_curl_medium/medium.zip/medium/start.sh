#!/bin/bash

echo "[+] terserah - start"
echo `nohup ./main &`