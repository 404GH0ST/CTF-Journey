#!/bin/bash

echo "[+] terserahs - start"
echo `nohup ./main &`