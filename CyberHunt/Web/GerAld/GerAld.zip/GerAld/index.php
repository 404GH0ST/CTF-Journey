<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple E-commerce Website</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Our E-commerce Store</h1>
        <input type="text" id="searchInput" placeholder="Search products..." oninput="searchProducts()">
    </header>
    <div id="productList">
       
    </div>

</body>
</html>
