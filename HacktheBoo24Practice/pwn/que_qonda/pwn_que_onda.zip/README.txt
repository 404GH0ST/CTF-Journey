🎃 h3ll0, fr13nd5! 🎃

This challenge is designed to help you get comfortable interacting with a remote instance, while also guiding you through the installation of essential tools. If you encounter any issues or notice anything missing, feel free to reach out to me via dm (#w3th4nds).

* To install the tools, run "./tools.sh" 1n y0ur 73rm1n4l.
* To interact with the challenge, spawn an instance and then use the command "nc <IP> <PORT>" e.g. "nc 127.0.0.1 1337"
* To run the solver script, run "./solver.py <IP> <PORT>" or "python3 solver.py <IP> <PORT>" e.g. "python3 solver 127.0.0.1 1337"
* This "HTB{f4ke_fl4g_4_t35t1ng}" is not the flag, just a placeholder.
* After that, you simply send the string "flag" to get the flag.
* "glibc" folder is not needed to exploit the challenge, it's given so you can run the challenge. 
* To run the challenge locally, enter in your terminal "./que_onda".

🎃 h4ppy h4ck1n6! 🎃
